#ifndef CAMERA_TYPE_H_
#define CAMERA_TYPE_H_

namespace GLOO {
enum class CameraType {
  Perspective,
  Fisheye,
};
}  // namespace GLOO

#endif