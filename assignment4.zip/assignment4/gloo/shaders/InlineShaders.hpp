#ifndef INLINE_SHADERS_H_
#define INLINE_SHADERS_H_

#include <string>


#endif
